﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _31ppp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Создаем экземпляр нового окна
            Window1 newWindow = new Window1();

            // Показываем новое окно
            newWindow.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(InputField_log.Text))
            {
                if (InputField_Pas.Password == "")
                {
                    label_pas.Content = "Введите Пароль";

                }
                else
                { // Создаем экземпляр нового окна
                    Window3 newWindow = new Window3();

                    // Показываем новое окно
                    newWindow.Show();
                    this.Close();
                }
            }
            else { label_log.Content = "Введите Логин"; }
        }
    }
}
