﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _31ppp
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(InputField.Text)){
                if (!string.IsNullOrWhiteSpace(InputField_1.Text))
                {
                    if (!string.IsNullOrWhiteSpace(InputField_2.Text))
                    {
                        // Создаем экземпляр нового окна
                        Window2 newWindow = new Window2();

                        // Показываем новое окно
                        newWindow.Show();
                        this.Close();
                    }
                    else { label3.Content = "Ввидите Email"; }
                }
                else { label2.Content = "Ввидите Имя"; }
            }
           
            else { label1.Content="Ввидите Фамилию"; }
        }

    }

}

