﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _31ppp
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(InputField0.Text))
            {
                if (InputField1.Password == "")
                {
                    label2.Content = "Введите Пароль";
                    
                }
                else
                { // Создаем экземпляр нового окна
                    MainWindow newWindow = new MainWindow();

                    // Показываем новое окно
                    newWindow.Show();
                    this.Close();
                }
            }
            else { label1.Content = "Введите Логин"; }
            
        }
    }
}
